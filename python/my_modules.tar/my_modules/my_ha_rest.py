#!/usr/bin/python3

# https://www.home-assistant.io/integrations/http/
# On top of the http integration is a REST API, Python API and WebSocket API available.

# https://developers.home-assistant.io/docs/api/rest/



# HTTP sensors : sensor, binary sensor
# https://www.home-assistant.io/integrations/http/#sensor

# the HTTP binary sensor is dynamically created with the first request that is made to its URL. 
# You don’t have to define it in the configuration first.
# The sensor will then exist as long as Home Assistant is running. 
# After a restart of Home Assistant the sensor will be gone until it is triggered again.

# To use those kind of sensors or binary sensors in your installation no configuration in Home Assistant is needed. 
# All configuration is done on the devices themselves

# You should choose a unique device name (DEVICE_NAME) to avoid clashes with other devices.

##### difference with REST API ?


version = 1.0 # 15 juillet 2025
version = 1.1 # 6 aout 2025

import json
import sys

import my_url

sys.path.append("/home/pi/APP/all_secrets")
try:
    import my_secret
    long_lived_token = my_secret.ha_token
except Exception as e:
    print("cannot import token")
    sys.exit(1)

s = "Bearer %s" %long_lived_token
headers = {
"Authorization": s,
"content-type": "application/json",
}


###################
# Home assistant REST API
# get one entity, return dict
# sensor created already
###################

def get_entity(entity_id:str, host="127.0.0.1"):

    url = "http://" + host +  ":8123/api/states/" + entity_id

    ret = my_url.url_request(url, method="get", headers=headers)

    if ret is None:
        print("cannot get home assistant entity")
        return(None)
    
    else:
        return(ret.json())
    



#################
# helper to easiliy create/update sensor, binary sensor
##################

# SENSOR: The JSON payload must contain the new state and should include the unit of measurement and a friendly name. The friendly name is used in the frontend to name the sensor.
# BINARY:The JSON payload must contain the new state and can have a friendly name. The friendly name is used in the frontend to name the sensor.

def update_http_sensor(sensor, state, host="127.0.0.1", app="unknown"):

    #############
    # attributes seems optional
    # home assistant creates attributes: last_ changed, reported, updated
    #############
    friendly_name = "%s_%s" %(app, sensor)
    d = {}
    d["friendly_name"] =  friendly_name 

    if state in ["on", "off" ]:   # do not use True here, as 0 is interpreted as True 
        # this is a binary sensor
        entity_id = "binary_sensor."+ sensor  
       
    else:
        entity_id = "sensor." + sensor

        d["unit_of_measurement"] = "X" # To be clear, unit_of_measurement is just a string and can be anything you want. There are only a few “special” uom values, such as “°C” and “°F”, where HA actually converts values to your locale settings when it sees them

    data_dict = {
        "state": state, 
    }
    # "attributes": d    # seems optional

    print("create/update:" , entity_id)

    # ha expect json, not dict
    ret= create_entity(entity_id, json.dumps(data_dict), host=host)

    if ret is None:
        print("cannot set home assistant http sensor. sensor: %s, state: %s, host: %s" %(sensor, state, host))
    
    # {'entity_id': 'binary_sensor.em_wifi', 'state': 'off', 'attributes': {}, 'last_changed': '2025-08-07T09:08:25.051790+00:00', 'last_reported': '2025-08-07T09:08:25.051790+00:00', 'last_updated': '2025-08-07T09:08:25.051790+00:00', 'context': {'id': '01K21WKTTV8523PGHF8G6PTQ9F', 'parent_id': None, 'user_id': '859204c7220f4c0dab694f80b489748c'}}
    
    return(ret)



################################
# not sure the difference with dynamic http sensors
################################


# The return code is 200 if the entity existed, 201 if the state of a new entity was set. 
# A location header will be returned with the URL of the new resource. The response body will contain a JSON encoded State object.

# Updates or creates a state. You can create any state that you want, it does not have to be backed by an entity in Home Assistant.
# # To delete the sensor, send DELETE

def create_entity(entity_id:str, data, host="127.0.0.1"):

    # entity_id: binary_sensor.DEVICE_NAME or sensor.DEVICE_NAME
    # You should choose a unique device name (DEVICE_NAME) to avoid clashes with other devices.
    # https://www.home-assistant.io/integrations/http/#sensor


    # SENSOR: The JSON payload must contain the new state and should include the unit of measurement and a friendly name. The friendly name is used in the frontend to name the sensor.
    # BINARY:The JSON payload must contain the new state and can have a friendly name. The friendly name is used in the frontend to name the sensor.
    
    try:
        l = entity_id.split(".")
        if l[0] not in ["binary_sensor", "sensor"]:
            print("bad entity id", entity_id)
            return(None)
    except:
        print("bad entity id", entity_id)
        return(None)
    
    # HA expect json, not dict
    
    url = "http://" + host +  ":8123/api/states/" + entity_id

    #data = {{"state": "25", "attributes": {"unit_of_measurement": "°C"}}}
    # {"state": "20", "attributes": {"unit_of_measurement": "°C", "friendly_name": "Bathroom Temperature"}}

    ret = my_url.url_request(url, method="post", headers=headers, data = data)

    if ret is None:
        print("cannot get home assistant entity")
        return(None)
    
    else:
        return(ret.json())


    

#######################
# http sensor
# dynamically created with the first request that is made to its URL.
# can check with dev tools, states
########################

# To use those kind of sensors or binary sensors in your installation no configuration in Home Assistant is needed. 
# All configuration is done on the devices themselves. 
# This means that you must be able to edit the target URL or endpoint and the payload. The entity will be created after the first message has arrived

# /api/states/binary_sensor.DEVICE_NAME
# {"state": "on", "attributes": {"friendly_name": "Radio"}}

# /api/states/sensor.DEVICE_NAME
# {"state": "20", "attributes": {"unit_of_measurement": "°C", "friendly_name": "Bathroom Temperature"}}

def create_http_sensor(entity_id:str, data_dict:dict, host="127.0.0.1"):

    url = "http://" + host +  ":8123/api/states/" + entity_id

    #data=json.dumps({"state": "on", "attributes": {"friendly_name": "Radio"}})

    data=json.dumps(data_dict)
    # or headers=,  json = data_dict ?

    ret = my_url.url_request(url, method="post", headers=headers, data=data)

    if ret is None:
        print("cannot create http sensor")
        return(None)
    
    else:
        return(ret.json())
        #{'entity_id': 'binary_sensor.titi', 
        # 'state': 'on', 
        # 'attributes': {'friendly_name': 'Radio'}, 
        # 'last_changed': '2025-07-15T09:28:53.989680+00:00', 'last_reported': '2025-07-15T09:28:53.989680+00:00', 
        # 'last_updated': '2025-07-15T09:28:53.989680+00:00', 
        # 'context': {'id': '01K06PMSZ52E6M2CB656J1MYYR', 'parent_id': None, 'user_id': '859204c7220f4c0dab694f80b489748c'}}



if __name__ == "__main__":


    # exist already
    entity_id = "input_number.shelly_max_temp_pilote"

    ret = get_entity(entity_id)

    if ret is not None:

        print(ret)
        # dict_keys(['entity_id', 'state', 'attributes', 'last_changed', 'last_reported', 'last_updated', 'context'])
        print(ret["state"])

    
    # dynamic HTTP sensor

    state = "on"
    entity_id = "binary_sensor.titi"
    data_dict = {
        "state": state, 
        "attributes": {"friendly_name": "Radio"}
    }

    
    ret= create_http_sensor(entity_id, data_dict)
    print(ret)

    if ret is not None:
        assert ret["state"] == state

    ret = get_entity(entity_id)
    print(ret)

    if ret is not None:
        assert ret["state"] == state


    
  