#!/usr/bin/python3

# to get local ssid
# iwgetid -r
# netsh wlan show interfaces

import subprocess
import platform
import shutil

# pip install in venv
import netifaces

version = 1.1 # 27 oct 2024. ping
version = 1.11 # 26 juillet 2025. get own IP

###############
# get ssid
###############
def get_ssid():
	# can fail if no wifi
	#data = subprocess.check_output(['netsh', 'WLAN', 'show', 'interfaces'])
	try:
		data = subprocess.check_output(['iwgetid', '-r'])
		#print(data) # b'Freebox-382B6B\n'
		data = data.decode('utf-8')
		print(data)
		return(data, None)
	except exception as e:
		return(None, str(e))

##############
# get file system free in %
##############
def get_fs_free(fs="/"):
	total, used, free = shutil.disk_usage(fs)
	return(int(100*free/total))

###################
# ping
###################
# return True if OK
def ping(host):

	param = '-n' if platform.system().lower()=='windows' else '-c'
	command = ['ping', param, '1', host]
	return subprocess.call(command) == 0


#################
# get own IP
#################
# socket.gethostbyname_ex does not work, returns only loopback

def get_own_ip(interface="wlan0"):

	assert interface in ["wlan0", "eth0"]

	# netifaces.ifaddresses('wlan0')
	#{17: [{'addr': 'dc:a6:32:60:73:a2', 'broadcast': 'ff:ff:ff:ff:ff:ff'}], 2: [{'addr': '192.168.1.221', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'}], 10: [{'addr': '2a01:e0a:25d:8b20:7283:ba40:d3cc:c1b8', 'netmask': 'ffff:ffff:ffff:ffff::/64'}, {'addr': 'fe80::aea7:82d0:26e4:5bf0%wlan0', 'netmask': 'ffff:ffff:ffff:ffff::/64'}]}
	
	# dict_keys([17, 2, 10])	17 loop ? , 2 is INET v4, 10 v6 ?
	
	# netifaces.ifaddresses('wlan0')[netifaces.AF_INET]
	# [{'addr': '192.168.1.221', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'}]

	# netifaces.AF_INET    is 2
	try:
		IP = netifaces.ifaddresses(interface)[netifaces.AF_INET]  # list  but only 1 as we specified wlan0
		IP = IP[0]
		IP = IP["addr"]
	except Exception as e:
		print("cannot get own ip with netifaces: %s" %str(e))
		IP = None

	return(IP)


if __name__ == "__main__":



	ip = get_own_ip()



	wifi = get_ssid()
	if "Freebox" in wifi:
		print("immeuble end S")
	else:
		print("Meaudre")

	fs = get_fs_free()
	print("%d %% free" %fs)

	for ip in ["192.168.1.1","192.169.1.1"]:
		if ping(ip):
			print("%s is up" %ip)
		else:
			print("%s is down" %ip)
