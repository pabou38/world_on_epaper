#!/usr/bin/python3

#dos2unix if created on remote vscode
# shelly 1PM

# BThome
# https://shelly.guide/bthome-components/

import json
import requests
from time import sleep
import datetime

import my_url

version = 1.1 # 28 oct 2024. EMpro gen2
version = 1.2 # 12 dec 
version = 1.21 # 12 juillet 2025 use my_url 

"""

####################
# GEN 2/3
####################

salon MiniG3
http://192.168.1.188/rpc/Switch.GetStatus?id=0
{"id":0, "source":"http", "output":true,
"temperature":{"tC":66.2, "tF":151.1}}

led 1PMliniG3
http://192.168.1.27/rpc/Switch.GetStatus?id=0
{"id":0, "source":"init", "output":false, 
"apower":0.0, "voltage":234.1, "freq":50.0, "current":0.000, 
"aenergy":{"total":85.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750770060}, 
"ret_aenergy":{"total":0.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750770060},
"temperature":{"tC":58.2, "tF":136.7}}


EM pro PROEM50
http://192.168.1.197/rpc/Switch.GetStatus?id=0
{"id":0, "source":"init", "output":false,"temperature":{"tC":44.3, "tF":111.7}}
# EM data in separate spaces

plugSG3
http://192.168.1.60/rpc/Switch.GetStatus?id=0
{"id":0, "source":"init", "output":true, "apower":7.1, "voltage":235.4, "freq":50.1, "current":0.055, 
"aenergy":{"total":3553.294,"by_minute":[0.000,210.738,210.738],"minute_ts":1750769160}, 
"ret_aenergy":{"total":0.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750769160},
"temperature":{"tC":51.4, "tF":124.5}}

ecs PRO1PM
http://192.168.1.190/rpc/Switch.GetStatus?id=0
{"id":0, "source":"init", "output":false, "apower":0.0, "voltage":233.4, "freq":50.0, "current":0.000, "pf":0.00, 
"aenergy":{"total":187336.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750769340}, 
"ret_aenergy":{"total":0.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750769340},
"temperature":{"tC":29.9, "tF":85.9}}


siren 1PM
http://192.168.1.29/rpc/Switch.GetStatus?id=0
{"id":0, "source":"init", "output":false, "apower":0.0, "voltage":222.2, "current":0.000, 
"aenergy":{"total":0.000,"by_minute":[0.000,0.000,0.000],"minute_ts":1750770840},
"temperature":{"tC":35.2, "tF":95.4}}

###################
# gen 1
###################

salon2 plug-s
http://192.168.1.189/rpc/Switch.GetStatus?id=0   DOES NOT WORK. gen 1 only ?

http://192.168.1.189/status
{"wifi_sta":{"connected":true,"ssid":"Livebox-deec","ip":"192.168.1.189","rssi":-66},
"cloud":{"enabled":true,"connected":true},"mqtt":{"connected":false},"time":"14:55","unixtime":1750769714,"serial":23221,"has_update":true,
"mac":"4022D883662A","cfg_changed_cnt":0,"actions_stats":{"skipped":0},
"relays":[{"ison":false,"has_timer":false,"timer_started":0,"timer_duration":0,"timer_remaining":0,"overpower":false,"source":"input"}],
"meters":[{"power":0.00,"overpower":0.00,"is_valid":true,"timestamp":1750776914,"counters":[0.000, 0.000, 86.059],"total":302}],
"temperature":22.63,"overtemperature":false,"tmp":{"tC":22.63,"tF":72.73, "is_valid":true},
"update":{"status":"pending","has_update":true,"new_version":"20230913-113421/v1.14.0-gcb84623","old_version":"20221027-101131/v1.12.1-ga9117d3","beta_version":"20231107-164219/v1.14.1-rc1-g0617c15"},
"ram_total":52072,"ram_free":39644,"fs_size":233681,"fs_free":166413,
"uptime":1050534}


i4
WTF. http://192.168.1.28/status  Not found. /shelly works

i3
http://192.168.1.30/status
http://192.168.1.31/status
{"wifi_sta":{"connected":true,"ssid":"Livebox-deec","ip":"192.168.1.30","rssi":-71},"cloud":{"enabled":true,"connected":true},
"mqtt":{"connected":false},"time":"15:08","unixtime":1750770511,"serial":2,"has_update":false,"mac":"E8DB84D66B55","cfg_changed_cnt":0,
"actions_stats":{"skipped":0},
"inputs":[{"input":0,"event":"","event_cnt":0,"last_sequence":""},
{"input":0,"event":"","event_cnt":0,"last_sequence":""},
{"input":0,"event":"","event_cnt":0,"last_sequence":""}],
"temperature_status":"Normal",
"update":{"status":"unknown","has_update":false,"new_version":"","old_version":"20230913-114336/v1.14.0-gcb84623"},
"ram_total":52368,"ram_free":39740,"fs_size":233681,"fs_free":155118,
"uptime":58}


i4

"""



###################
# gen 1 API
###################

def gen1_set_relay(host:str, b:bool):

    if b:
        print('turn relay on')
        url =  "http://" +  host + "/relay/0?turn=on"
    else:
        print('turn relay off')
        url =  "http://"  + host + "/relay/0?turn=off"

    res = my_url.url_request(url, "post")

    if res is None:
        print("error gen 1 set relay")
    else:
        print ('is on: ', res.json()['ison'])


def gen1_status(host:str):

    url =  "http://"  + host + "/status"

    res = my_url.url_request(url)

    if res is None:
        print("error gen1 status")
        return(None)

    else:
        # meter and relay info
        #print ('power drawn Watt', res.json()['meters'] [0] ['power']) # Current real AC power being drawn, in Watts
        #print ('meter self check ', res.json()['meters'] [0] ['is_valid'])
        #print ('time stamp ', datetime.datetime.fromtimestamp(res.json()['meters'] [0] ['timestamp']))
        #print ('total Wmn ', res.json()['meters'] [0] ['total']) #Total energy consumed by the attached electrical appliance in Watt-minute
        #print ('last 3mn, in Wm ', res.json()['meters'] [0] ['counters']) #Energy counter value for the last 3 round minutes in Watt-minute
        #print ('is on ', res.json()['relays'][0]['ison'])
        #print ('overpower ', res.json()['relays'][0]['overpower'])
        #print ('temp ', res.json()['temperature'], res.json()['temperature_status'])

        return(res.json())
    


        """
        get status
        power drawn Watt 30.63
        meter self check  True
        time stamp  2022-10-19 12:16:12
        total Wmn  15
        last 3mn, in Wm  [0.0, 0.0, 0.0]
        is on  True
        overpower  False
        temp  33.78 Normal
        """


################
# cloud API
################
def cloud_get_status(server:str, id:str, key:str):

    url =  "http://"  + server + "/device/status?id=%s&auth_key=%s" %(id,key)
    res = my_url.url_request(url)

    if res is not None:
        return(res.json())
    
    else:
        return(None)
    
    
def cloud_turn_relay(server:str, id:str, key:str, b:bool):

    if b:
        t = "on"
    else:
        t = "off"

    url =  "http://"  + server + "/device/relay/control?id=%s&auth_key=%s&channel=0&turn=%s" %(id, key, t)
 
    res = my_url.url_request(url, "post")

    if res is not None:
        return(res.json())  
    else:
        return(None)


#####################
# gen 2+ API
#####################
# https://shelly-api-docs.shelly.cloud/gen2/General/ComponentConcept



#################
# status
#################

# for complete device, not only switch
# http://192.168.1.27/rpc/Switch.GetStatus?id=0  for switch only
def gen2_status(server:str):

    url =  "http://"  + server + "/rpc/Shelly.GetStatus"

    res = my_url.url_request(url)

    if res is not None:
        return(res.json())
    else:
        return(None)

    
#################
# config
#################

def gen2_config(server:str):

    url =  "http://" + server + "/rpc/Shelly.GetConfig"

    res = my_url.url_request(url)

    if res is not None:
        return(res.json())
    else:
        return(None)


###############################################
# enery meter

#  gen 3
# https://shelly-api-docs.shelly.cloud/gen2/Devices/Gen3/ShellyEMG3
# 1 instance of Switch (switch:0)
# 2 instances of EM1 (em1:0, em1:1)
# 2 instances of EM1Data (em1data:0, em1data:1)

# PRO gen 2
# https://shelly-api-docs.shelly.cloud/gen2/Devices/Gen2/ShellyProEM
# 1 instance of Switch (switch:0)
# 2 instances of EM1 (em1:0, em1:1)
# 2 instances of EM1Data (em1data:0, em1data:1)
# The Modbus component provides Modbus-TCP communication protocol on tcp port 502

###############################################

##################
# EM get power
# ====== >this is what to call to get power
# act_power in W (Watts)
##################



# EM1.GetStatus
# The momentary values of the current in A (Amps), voltage in V (Volts), act_power in W (Watts), aprt_power in VA (Volt-Ampere), pf - power factor is dimensionless, freq - network frequency in Hz.

def get_em_power(server:str, id:int):

    """
    http://192.168.1.197/rpc/EM1.GetStatus?id=0
    {'act_power': 0.0,
    'aprt_power': 4.5,
    'calibration': 'factory',
    'current': 0.02,
    'freq': 50.0,
    'id': 0,
    'pf': 0.0,
    'voltage': 221.8}
    """
    # {"id":0,"voltage":230.6,"current":0.020,"act_power":0.0,"aprt_power":4.7,"pf":0.00,"freq":50.0,"calibration":"factory"}

    # http:// and  / added, need 192.168.1.X as param

    url = "http://" + server + "/rpc/EM1.GetStatus?id=%d" %id

    res = my_url.url_request(url)

    if res is None:
        print("error gen 2 get em power")
        return(None)

    else:
        # Active power measurement value, [W]
        power = res.json()["act_power"]

        va = res.json()["current"] * res.json()["voltage"]

        #print("power: %0.2f, va: %0.2f" %(power, va))
        # power: 1767.80, va: 1765.23   radiateur
        # va = power

        return(power)
       


##################
# EM get energy
# The status of the EM1Data component contains information about the perpetual counters and possible errors.
# /EM1Data.GetStatus
# total_act_energy Total active energy, Wh
# total_act_ret_energy Total active returned energy, Wh
##################

def get_em_energy(server:str, id:int):
    url =  "http://"  + server + "/rpc/EM1Data.GetStatus?id=%d" %id
    #print(url)

    # {'id': 0, 'total_act_energy': 457.54, 'total_act_ret_energy': 1.52}
    # {"id":0,"total_act_energy":0.00,"total_act_ret_energy":0.00}

    res = my_url.url_request(url)

    if res is None:

        print("error gen 2 get em energy")
        return(None)


    else:
       r = res.json()
       # Total active energy, Wh
       return(r["total_act_energy"])



##################
# get DATA from an energy meter
# energy and min/max power
##################

# EM ShellyPro3EM.  EM1 ShellyProEM.
# WARNING: EMdata, EM1data

# Shelly gen 2 PRO EM uses 2 instances of EM1 (em1:0, em1:1), 2 instances of EM1Data (em1data:0, em1data:1)
# same for gen3, uses EM1
# NOTE: Shelly Pro 3 EM (400) gen 2 (tri phase) 1 instance of EM (em:0), 3 instances of EM1 (em1:0, em1:1, em1:2)

# The EM1Data component stores data from an energy meter
# EM1Data.GetData to get saved emeter data values
# https://shelly-api-docs.shelly.cloud/gen2/ComponentsAndServices/EM1Data#em1datagetdata-example

#  If the response is too big if will be chunked
# TO READ: ts = 0  LIKELY NO LATEST records  

# Usually EM1Data.data will be an array containing a single object. 
# There will be situations when the records will be interrupted (power loss) and then the array will contain more than one item

def get_em1_data(server:str, id:int):

   # http://192.168.33.1/rpc/EM1Data.GetData?id=0&ts=1656356400&end_ts=1656356800
   # ts UNIX timestamp of the first record. Any record with data having a timestamp between ts and end_ts will be retrieved.
   # end_ts UNIX timestamp of the last record to get (if available). If the response is too big, it will be chunked. The default is to get all available records without limit.

    url =  "http://"  + server + "/rpc/EM1Data.GetData?id=%d&ts=0" %id
    print(url)

    res = my_url.url_request(url)

    if res is None:
        print("error gen 2 get em1 data")
        return(None)
    else:
        r = res.json()
        # dict_keys(['keys', 'data', 'next_record_ts'])


        # energy and min/max power
        # "keys": ["total_act_energy","total_act_ret_energy","lag_react_energy","lead_react_energy","max_act_power","min_act_power","max_aprt_power","min_aprt_power","max_voltage","min_voltage","avg_voltage","max_current","min_current","avg_current"]

        # "next_record_ts":1749105780

        # "data":[{"ts": 1749103920,"period": 60,"values":[[0.0000,0.0000,0.0000,0.0000,-0.0,-0.0,4.8,4.7,230.961,230.268,230.740,0.021,0.020,0.020 ],
        #       data is a list of dict , usually 1 more if power loss

        print("EM data for id:", id)
        print("next record ts:", datetime.datetime.fromtimestamp(r["next_record_ts"]))
        print("%d value available" %len(r["keys"]))
        nb_values = len(r["keys"])
        print("valuesn available: %s" %r["keys"])
        print("%d records available (>1 if power loss)" %len(r["data"]))  # list of dict, >1 if power loss


        #  If the response is too big

        for x in r["data"]: # list of dict
            print("\nstarting ts:", datetime.datetime.fromtimestamp(x["ts"]))
            print("period:", (x["period"]))

            values = x["values"]  # is a list of list
            print("number of samples: %d" %len(values))
            for y in values:
                print(y)  # each is a list of 14 
                assert len(y) == nb_values

        pass


########################
# # EM1Data.GetRecords to get saved emeter data time intervals
# EM1Data.GetRecords to get saved emeter data time intervals
########################
def get_em1_records(server:str, id:int):

    # UNIX timestamp of the first interval. Used for selecting the next data chunk when the response is too large to fit in one call. Default is 0.

    url =  "http://"  + server + "/rpc/EM1Data.GetRecords?id=%d&ts=0" %id
    print(url)

    res = my_url.url_request(url)

    if res is None:
        print("error gen 2 get em1 recordsr")
        return(None)

    else:
        r = res.json()
        print(r)

        # {'data_blocks': [{'ts': 1749103920, 'period': 60, 'records': 217}]}




##########################
# cloud API
##########################

def cloud_api():

    # for cloud API
    sys.path.append("../all_secrets")
    import my_secret

    # https://shelly-api-docs.shelly.cloud/gen1/#shelly1-shelly1pm
    # https://shelly-api-docs.shelly.cloud/cloud-control-api/communication 
    # The request is HTTPS POST to the Server your devices are hosted at.
    solar_1 = "http://192.168.1.188/" # 1PM
    solar_2 = "http://192.168.1.189/" # plugS
 
    ################################
    # cloud API using device id
    ################################
    solar_1_id = my_secret.solar_1
    solar_2_id = my_secret.solar_2
    auth_key = my_secret.shelly_cloud_auth_key 
    server_uri = my_secret.shelly_cloud_server_uri

    print("\ngetting status (cloud) for:", solar_1_id)
    j = cloud_get_status(server_uri, solar_1_id, auth_key)
    pprint.pprint(j)


    #print("\nturning relay off (cloud) for:", solar_2_id)
    #j = cloud_relay(server_uri, solar_2_id, auth_key, False)
    #pprint.pprint(j)

#########################
# main
#########################

if __name__ == "__main__":

    import sys
    import pprint

    ###################
    # pro EM-50
    # https://shelly-api-docs.shelly.cloud/gen2/Devices/Gen2/ShellyProEM
    ###################
    em_pro = "192.168.1.197"
    ct_pro = [0,1]

    em_gen3 = "192.168.1.196"
    ct_gen3 = [0]

    # test gen 3
    my_em = em_gen3
    my_ct = ct_gen3


    # test EM pro
    my_em = em_pro
    my_ct = ct_pro


    #x = get_em1_data(my_em, 0)


    ####################
    # simple print ct power forever
    ###################
    def loop_power(my_em, my_ct):
        while True:
            # power
            for ct in my_ct:
                power = get_em_power(my_em,ct)

                if power is not None:
                    print("ct: %d. power: %0.1fW" %(ct, power))

            sleep(2)


    #################
    # print power, energy, EM1 data, EM1 record, status, config
    ################
    def full_print_em(my_em, my_ct):

        for ct in my_ct:

            power = get_em_power(my_em, ct) # use status
            if power is not None:
                print("ct: %d. power: %0.1f" %(ct,power))

            energy = get_em_energy(my_em,ct)
            if energy is not None:
                print("ct: %d. total active energy: %0.1fWh" %(ct, energy))

            get_em1_data(my_em,ct)

            get_em1_records(my_em, ct)


        # The status of the EM1Data component contains information about the perpetual counters and possible errors.
        j = gen2_status(my_em)
        if j is not None:
            pprint.pprint(j)


            print("EM0 active power: %0.1fW" %j["em1:0"] ["act_power"])
            print("EM0 apparent power: %0.1fW" %j["em1:0"] ["aprt_power"])
            print("EM0 V*A: %0.1fW" %(j["em1:0"] ["current"] * j["em1:0"] ["voltage"]))


            print("EM1 active power: %0.1fW" %j["em1:1"] ["act_power"])
            print("EM1 apparent power: %0.1fW" %j["em1:1"] ["aprt_power"])
            print("EM1 V*A: %0.1fW" %(j["em1:1"] ["current"] * j["em1:1"] ["voltage"]))

            try: 
                print("switch temp: %0.1fC" %j["switch:0"] ["temperature"] ["tC"])
            except:
                print("no temp")

        else:
            print("status for %s failed" %my_em)


        # config
        j = gen2_config(my_em)
        if j is not None:
            pprint.pprint(j)
            # long 


    #full_print_em(my_em, my_ct)

    loop_power(my_em, my_ct)
