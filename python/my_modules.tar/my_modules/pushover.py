#!/usr/bin/python3

version = 1.0 # 10/07/2024 pavillon add response

# i8suasztme@pomail.net

# app: domoticz , gabion, teleinfo, thingspeak, pi tinkering

# The httplib module has been renamed to http.client in Python 3.0.
# This module defines classes which implement the client side of the HTTP and H>
# the module urllib uses it to handle URLs that use HTTP and HTTPS.
import http.client as httplib  # httplib only P2
import urllib
import logging
import datetime
import time
import json

import sys
sys.path.append("../all_secret") # do not push this directory to github !!

import my_secret

# https://pushover.net/api#sounds
# https://support.pushover.net/i44-example-code-and-pushover-libraries

# https://pushover.net/api

# token=azGDORePK8gMaC0QOYAMyEEuzJnyUi&user=uQiRzpo4DXghDmr9QzzfQu27cmVRsG
# &device=droid4
# &title=Backup+finished+-+SQL1
# &message=Backup+of+database+%22example%22+finished+in+16+minutes.

# HTTPS is required for all API calls, and for security purposes, your application should enable your HTTP library's TLS/SSL verification. 
# The POST method is required be used for the API call to push messages.


# python3
def send_pushover(message:str, title= "pushover from python", priority= 0, sound = "spacealarm", prefix = "solar2heater: "):
    
    # some prefix to the message text
    message = prefix + message

    conn = httplib.HTTPSConnection("api.pushover.net:443")

    conn.request("POST", "/1/messages.json",

    urllib.parse.urlencode({
        "token": my_secret.pushover["pushover_token"],
        "user": my_secret.pushover["pushover_user"],
        "message": message,
        "priority" : priority,
        "sound" : sound,
        "title" : title
        }), { "Content-type": "application/x-www-form-urlencoded" })
    
    resp = conn.getresponse() # <http.client.HTTPResponse object at 0xf64c5f58>
    respBody = resp.read()
    responseObject = json.loads(respBody)
    
    #print(responseObject) # {'status': 1, 'request': '6703ba7a-a4e6-4518-acbf-7704db794a39'}

    # If your POST request to our API was valid, you will receive an HTTP 200 (OK) status, with a JSON object containing a status code of 1.


    try:
        logging.info(' send pushover:' + message )
    except:
        pass
    
    try:
      if responseObject["status"] == 1:
          return(True)
      else:
        print(responseObject) 
        return(False)
    except:
      print(responseObject) # {'status': 1, 'request': '6703ba7a-a4e6-4518-acbf-7704db794a39'}
      return(False)
    



if __name__ == "__main__":
    
  print("sending pushover")
  send_pushover('testing', priority=0, sound='cosmic')



"""
import requests
r = requests.post("https://api.pushover.net/1/messages.json", data = {
  "token": "APP_TOKEN",
  "user": "USER_KEY",
  "message": "hello world"
},
files = {
  "attachment": ("image.jpg", open("your_image.jpg", "rb"), "image/jpeg")
})
"""

"""
pushover - Pushover (default)   
bike - Bike   
bugle - Bugle   
cashregister - Cash Register   
classical - Classical   
cosmic - Cosmic   
falling - Falling   
gamelan - Gamelan   
incoming - Incoming   
intermission - Intermission   
magic - Magic   
mechanical - Mechanical   
pianobar - Piano Bar   
siren - Siren   
spacealarm - Space Alarm   
tugboat - Tug Boat   
alien - Alien Alarm (long)   
climb - Climb (long)   
persistent - Persistent (long)   
echo - Pushover Echo (long)   
updown - Up Down (long)   
vibrate - Vibrate Only
none - None (silent)
"""

"""
Lowest Priority (-2)
When the priority parameter is specified with a value of -2, messages will be considered lowest priority and will not generate any notification. On iOS, the application badge number will be increased.

Low Priority (-1)
Messages with a priority parameter of -1 will be considered low priority and will not generate any sound or vibration, but will still generate a popup/scrolling notification depending on the client operating system. Messages delivered during a user's quiet hours are sent as though they had a priority of (-1).

Normal Priority (0)
Messages sent without a priority parameter, or sent with the parameter set to 0, will have the default priority. These messages trigger sound, vibration, and display an alert according to the user's device settings. On iOS, the message will display at the top of the screen or as a modal dialog, as well as in the notification center. On Android, the message will scroll at the top of the screen and appear in the notification center.

If a user has quiet hours set and your message is received during those times, your message will be delivered as though it had a priority of -1.

High Priority (1)
Messages sent with a priority of 1 are high priority messages that bypass a user's quiet hours. These messages will always play a sound and vibrate (if the user's device is configured to) regardless of the delivery time. High-priority should only be used when necessary and appropriate.
"""
