#!/usr/bin/python3

import json
import requests
from time import sleep
import datetime

version = 1.0 # 12 juillet 2025
version = 1.01 # 15 juillet 2025 add headers, data
version = 1.02 # 17 juillet 2025 response 201 considered valid (create new HA sensor)


######################
# generic url processing
######################

def url_request(url, method="get", headers=None, data=None):

    try:
        if method == "get":
            res = requests.get(url, headers=headers)
        elif method == "post":
            res = requests.post(url, headers=headers, data=data)
        else:
            return(None)

    except Exception as e: # timeout exception is IP not there
        print("Exception request", str(e))
        return(None)


    ########################
    # 201 dynamically created HA entities 
    #######################
    if res.status_code not in [200, 201] or not res.ok:
        print('error REST for %s. status code: %s, ok: %s' %(url, res.status_code, res.ok))
        print(res.text)  # may not be a json
        return(None)
    else:
        return(res) # let caller call res.json()



