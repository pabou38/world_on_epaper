#!/usr/bin§python3

version = 1.0 # 16 juiller 2025

import subprocess

# Run the command described by args. Wait for command to complete, then return a CompletedProcess instance.

#You need to supply shell=True to execute the command through a shell interpreter. If you do that however, you can no longer supply a list as the first argument, because the arguments will get quoted then. 
# Instead, specify the raw commandline as you want it to be passed to the shell:
def subprocess_run(cmd, shell=False):

	if not shell:
		assert isinstance(cmd, list)

	if shell:
		assert isinstance(cmd, str)

	result = subprocess.run(cmd, shell=shell, capture_output=True, text=True, timeout=30, check=False)

    # If shell is True, the specified command will be executed through the shell. convenient access to other shell features such as shell pipes, filename wildcards, environment variable expansion, and expansion of ~ to a user’s home director
	# If text mode is not used, stdin, stdout and stderr will be opened as binary streams. No encoding or line ending conversion is performed.
    # If capture_output is true, stdout and stderr will be captured. 
	# If check is true, and the process exits with a non-zero exit code, a CalledProcessError exception will be raised. Attributes of that exception hold the arguments, the exit code, and stdout and stderr if they were captured.
    

	#####################
	# return a CompletedProcess instance
	#####################

	# The arguments used to launch the process
	#print("args", result.args)

	# Exit status of the child process. Typically, an exit status of 0 indicates that it ran successfully.
	# A negative value -N indicates that the child was terminated by signal N (POSIX only).
	#print("returncode", result.returncode)

	# Captured stderr from the child process. A bytes sequence, or a string if run() was called with an encoding, errors, or text=True. None if stderr was not captured.
	#print("stderr:\n", result.stderr)
	#print("stdout:\n", result.stdout)

	# If returncode is non-zero, raise a CalledProcessError.
	try:
		result.check_returncode()
	except Exception as e:
		print(str(e))

	return(result)


if __name__ == "__main__":

	result = subprocess_run(["ls", "-a"])
	#print(result)
	if result.returncode !=0:
		print("failed, stderr:\n%s" %result.stderr)
	else:
		print("ok, stdout:\n%s" %result.stdout)
