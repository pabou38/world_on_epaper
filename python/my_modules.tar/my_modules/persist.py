#!/usr/bin/python3

import json

version = 1.0


################################
# persist data in json file
################################
# eg use across reboot


def create_persist(file, dict):

    try:
        with open(file, "w") as f:
            json.dump(dict, f)

        # read back
        with open(file, 'r') as f:
            d = json.load(f)
        print(d)

        return(d)
    except Exception as e:
        print("Exception create persist: %s" %str(e))
        return(None)


def read_persist(file, key):

    try:
        with open(file, 'r') as f:
            d = json.load(f)
        return(d[key])
    
    except Exception as e:
        print("Exception: %s. cannot access %s in json file %s" %(str(e), key,file))
        return(None)
        
        
def update_persist(file, key, value):

    try:
        with open(file, 'r') as f:
            d = json.load(f)
            d[key] = value

        with open(file, 'w') as f:
            json.dump(d, f)
            return(d)

    except Exception as e:
        print("Exception: %s cannot update key %s with value %s in file %s" %(str(e), key, str(value), file))
        return(None)
    

if __name__ == "__main__":

    print("create persist")
    d = {"test":1}

    file = "/home/pi/ramdisk/persist.log"

    ret = create_persist(file, d)
    if ret is None:
        print("create persist error")
    else:
        print(ret)
        assert ret == d

        print("read persist")
        print(read_persist(file, "test"))

        print("update persist")

        val = 2
        update_persist(file, "test", val)
    
        assert val == read_persist(file, "test")

        pass



