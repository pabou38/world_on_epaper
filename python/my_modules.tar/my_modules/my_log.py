#!/usr/bin/python3

version = 1.1  # 14/05/2024  new victor
version = 1.2  # 21/06/2025  multiple logger

import datetime
import logging
import os, sys
import platform

from logging import FileHandler
from logging import Formatter


###############################
# various system parameters
###############################

def view_system():
    print( "system:", platform.system())
    print( "processor:", platform.processor())
    print( "machine:", platform.machine())
    print( "system:", platform.system())
    print( "version:", platform.version())
    print( "uname:", platform.uname())
    print( "node:", platform.node())

    os.environ["PYTHONIOENCODING"] = "utf8"
    print('default encoding', sys.getdefaultencoding())
    print('file system encoding', sys.getfilesystemencoding())

    # env variable set in .vscode/launch.json
    try:
        print('author from env variable ', os.environ['author'])
    except:
        pass  # env variable not defined in colab

    
    if sys.platform in ["win32"]:
        print("running on WINDOWS on system: " , platform.node())
        colab=False # proceed from training to real time audio
    
    elif sys.platform in ['linux']:
        print("running on linux on system: ", platform.node())
        # os: posix, sys.platform: linux, platform.machine: x86_64
        colab = True # to stop at the end of training, and not go in audio, remi, flask 

   

def running_on_edge():
    # bool to determine if we are running on the Jetson/PI 
    # eg do not evaluate model after loading, 
    # running_on_edge = sys.platform in ["linux"]
    return(platform.processor in ["aarch64"])

def running_on_colab():
    ##### TO DO
    return(False)

    



#############################
# time stamp
#############################
def get_stamp():

    d = datetime.datetime.now()

    s = "%d/%d-%d:%d" %(d.month, d.day, d.hour, d.minute)

    return(s)


#################################
# get logger
#################################

# https://docs.python.org/3/howto/logging.html
# https://blog.muya.co.ke/configuring-multiple-loggers-python/

# DO NOT mess around with basic_config. has issues with two loggers

def get_log(log_file="my_log.log", level = logging.INFO, root = ".", name="my_logger"):

    # root + logfile

    log_file = os.path.join(root,log_file)
    
    # debug, info, warning, error, critical

    print ("logging to:  " , log_file)

    if os.path.exists(log_file) == False:
        with open(log_file, "w") as f:
            pass  # create empty file

    print("logging level", level)

    # https://docs.python.org/3/howto/logging.html#changing-the-format-of-displayed-messages
    # https://docs.python.org/3/library/logging.html#logrecord-attributes

    LOG_FORMAT = ( "%(asctime)s [%(levelname)s] FROM: %(name)s, CONTENT:  %(message)s, AT: %(pathname)s:%(lineno)d")
    # 2025-07-13 10:26:46,489 [INFO] FROM: shelly, CONTENT:  monitor shelly relay temp.  version 1.00, AT: /home/pi/APP/homeassistant/python_app/shelly_temp.py:32


    # define a name (used in %(name)s )
    # name are any hiearchy
    # use root if not defined (ie use logging.info vs logger.info )
    # importing logging in all modules easier


    # https://docs.python.org/3/howto/logging.html#logging-from-multiple-modules

    logger = logging.getLogger(name)

    logger.setLevel(level)
    logger_file_handler = FileHandler(log_file)
    logger_file_handler.setLevel(level)
    logger_file_handler.setFormatter(Formatter(LOG_FORMAT))
    logger.addHandler(logger_file_handler)

    # The call to basicConfig() should come before any calls to debug(), info()
    # https://docs.python.org/3/library/logging.html#logging.basicConfig

    return(logger)


def tf_log_level():

    import tensorflow as tf
    
    
    logging.getLogger("tensorflow").setLevel(logging.ERROR)
    """
    0 = all messages are logged (default behavior)
    1 = INFO messages are not printed
    2 = INFO and WARNING messages are not printed
    3 = INFO, WARNING, and ERROR messages are not printed
    """

    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' 

    # prevent spitting too much info ?
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 

    # prevent spitting too much info ?
    tf.get_logger().setLevel('ERROR')
    tf.autograph.set_verbosity(0)

if __name__ == "__main__":

    logger = get_log("test_log.log", level = logging.DEBUG, root=".", name="test1")

    logger.info('testing info')
    logger.debug('testing debug')


    logger1 = get_log("test_log1.log")

    logger1.info('testing info')
    logger1.debug('testing debug')

    # 2025-07-13 10:26:46,489 [INFO] FROM: shelly, CONTENT:  monitor shelly relay temp.  version 1.00, AT: /home/pi/APP/homeassistant/python_app/shelly_temp.py:32






   





