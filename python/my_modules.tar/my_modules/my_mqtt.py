#!/usr/bin/python3

#pip install paho-mqtt
# Successfully installed paho-mqtt-2.1.0

# https://github.com/eclipse-paho/paho.mqtt.python

# full doc
# https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html

# helpers
# https://eclipse.dev/paho/files/paho.mqtt.python/html/helpers.html



########################
# PYTHON MQTT
########################

version = 1.0 # juillet 2025

import json

import paho.mqtt.client as mqtt

# helpers
import paho.mqtt.subscribe as subscribe
import paho.mqtt.publish as publish
from paho.mqtt.enums import MQTTProtocolVersion

import random
from  time import sleep

port = 1883


# API v2
# property is MQTT v5 only. empty in v3

will_topic = "meaudre/test/will"
will_payload = "offline" # send by broker

online_payload = "online"

got_msg = False # wait for callback


######################
# call back connect
######################

# # The callback for when the client receives a CONNACK response from the server.
# on_connect(): called when the CONNACK from the broker is received. 
# The call could be for a refused connection, check the reason_code to see if the connection is successful or rejected.

def on_connect(client, userdata, flags, reason_code, properties):


    # reqson code: the connection reason code received from the broken. In MQTT v5.0 it’s the reason code defined by the standard. In MQTT v3, we convert return code to a reason code
    # ReasonCode may be compared to integer.

    # ReasonCode(Connack, 'Success')
    # reason_code.is_failure   bool
    # reason_code.value 0 if success
    # str(reason_code)

    #1: Connection refused - incorrect protocol version
    #2: Connection refused - invalid client identifier
    #3: Connection refused - server unavailable
    #4: Connection refused - bad username or password
    #5: Connection refused - not authorised
    #6-255: Currently unused.

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    #client.subscribe("$SYS/#")

    if reason_code.is_failure:
        print("connect failure")
    else:
        print("connect OK")

    print("on_connect: reason code: %s" %(str(reason_code)))
    # on_connect: reason code: Success

    #print("on_connect: reason code value %d" %(reason_code.value)) # does not seem rigth

    # userdata – the private user data as set in Client() or user_data_set()
    print("user data %s" %str(userdata))

    print("properties (only v5) %s" %(str(properties)))
    # properties (only v5) [ReceiveMaximum : 20, TopicAliasMaximum : 10]
    # UTF-8 string key-value pairs



def on_disconnect(client, userdata, disconnect_flags, reason_code, properties):
    print("on disconnect. reason code %s" %str(reason_code))


##########################
# call back topics
##########################
# https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html#paho.mqtt.client.Client.on_subscribe

# reason_code_list
#   reason codes received from the broker for each subscription. 
#   In MQTT v5.0 it’s the reason code defined by the standard. In MQTT v3, we convert granted QoS to a reason code. It’s a list of ReasonCode instances.
# granted_qos (list[int]) – list of integers that give the QoS level the broker has granted for each of the different subscription requests.

#[ReasonCode(Suback, 'Granted QoS 0')]
# [0].getName()  'Granted QoS 0'
# [0].getId( name above)
# [0].is_failure

def on_subscribe(client, userdata, mid, reason_code_list, properties):

    for rc in reason_code_list:
        if rc.is_failure:
            print("broker rejected subscription %s. code %d" %(rc.getName(), rc.getId(rc.getName())))
        else:
            print("broker accepted subscription. granted QOS %d" %rc.value)


def on_unsubscribe(client, userdata, mid, reason_code_list, properties):
    # Be careful, the reason_code_list is only present in MQTTv5.
    # In MQTTv3 it will always be empty
    if len(reason_code_list) == 0 or not reason_code_list[0].is_failure:
        print("on unsubscribe callback: unsubscribe succeeded (if SUBACK is received in MQTTv3 it success)")
    else:
        print(f"on unsubscribe callback: Broker replied with failure: {reason_code_list[0]}")

    #client.disconnect()



##########################
# call back message
##########################

# called when an MQTT message was sent to the broker. 
# Depending on QoS level the callback is called at different moment:
# For messages with QoS levels 1 and 2, this means that the appropriate handshakes have completed.
# For QoS 0, this simply means that the message has left the client. This callback is important because even if the publish() call returns success, it does not always mean that the message has been sent.
# See also wait_for_publish which could be simpler to use. 


def on_publish(client, userdata, mid, reason_code, properties):
   # reason_code and properties will only be present in MQTTv5. It's always unset in MQTTv3
   print("on_publish callback: mid %d, user data %s. reason_code: %s. properties: %s " %(mid, str(userdata), str(reason_code), str(properties)))

   # on_publish callback: mid 1, user data publish. reason_code: Success. properties: [] 

   # userdata – the private user data as set in Client() or user_data_set()

   # will change my_userdata !!!! 
   userdata.add (2)



# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    global got_msg

    print("on_message callback topic %s" %(msg.topic))
    print("on_message callback payloaad %s" %str((msg.payload)))
    print("on_message callback userdata: %s" %str(userdata))

    # on_message callback topic meaudre/test/sub:
    # on_message callback payloaad b'hello you':

    got_msg = True


########################
# wrapper for creating client and  connect
########################

def connect_to_ha_mqtt(username, password, host ="127.0.0.1", protocol = mqtt.MQTTv31, userdata = ["PABOU,"], persistant=False):

    # L'identifiant client est une chaîne de 23 octets qui identifie un client MQTT . Chaque identifiant doit être unique pour un seul client connecté à la fois
    # If you do not specify a client_id, a random id will be generated for you (and clean_session must be set to True).
    client_id = "mqtt-client-id%d" %(random.randint(0, 1000))


    # PERSISTANT SESSION
    # When the cleanSession flag is set to true, the client explicitly requests a non-persistent session; 
    # it true the broker will remove all information about this client when it disconnects.


    # Session existence (even if there are no subscriptions):
    # All client’s subscriptions:
    # Flow of all messages in a Quality of Service (QoS) 1 or 2 where the client has not yet confirmed: 
    # All new QoS 1 or 2 messages that the client missed while offline
    # All QoS 2 messages received from the client that are awaiting complete acknowledgment

    # v3 , can include in Client ; v5 cannot, use in connect and call it clean_start

    clean_session = not persistant# v3
    clean_start = clean_session # v5

    # userdata – user defined data of any type that is passed as the “userdata” parameter to callbacks. It may be updated at a later point with the user_data_set() function.

    
    if protocol == mqtt.MQTTv5:

        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id, userdata=userdata, protocol=protocol )

    else:
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id, clean_session = clean_session, userdata=userdata, protocol=protocol )

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect

    client.on_publish = on_publish
    client.on_message = on_message

    client.on_subscribe = on_subscribe
    client.on_unsubscribe = on_unsubscribe

    client.user_data_set(userdata)

    client.username_pw_set(username, password)


    ############
    # will
    ############
    # allows clients to specify a message that will be automatically published by the broker on their behalf, if or when an unexpected disconnection occurs.
    # lastWillMessage with Offline payload, enabling the lastWillRetain flag, and specifying the lastWillTopic as client1/status,
    # Publishing an Online retained message to the same topic,
    # Should client1 disconnect unexpectedly, the broker publishes the LWT message with Offline payload as the new retained message,

    # https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html#paho.mqtt.client.Client.will_set

    client.will_set(will_topic, payload=will_payload, qos=0, retain=True)


    ##############
    # connect
    ##############

    # bind_address, which allows the socket to be bound to a specific address at the local side of the connection, useful if you have more than one outgoing interface.
    
    # The connect() call blocks until the socket connection is made with the broker, but is asynchronous afterwards, so once it returns you cannot be sure that the broker has accepted the connection 
    # # – the on_connect() callback should be used for this purpose
    
    
    # Connect to a remote broker. This is a blocking call that establishes the underlying connection and transmits a CONNECT packet. 
    # Note that the connection status will not be updated until a CONNACK is received and processed 
    # (this requires a running network loop, see loop_start, loop_forever, loop…).


    if protocol == mqtt.MQTTv5:   
        client.connect(host, port, clean_start= clean_start)
    else:
        client.connect(host, port)

    return(client)



    
# LOOP FOREVER
#client.loop_forever() will block, processing the network traffic and reconnecting automatically as necessary. 
# This function is most useful if you are only subscribing to the broker and acting on the messages you receive.
# Blocking call that processes network traffic, dispatches callbacks and handles reconnecting.
# This is a blocking form of the network loop and will not return until the client calls disconnect(). It automatically handles reconnecting.

# Other loop*() functions are available that give a threaded interface and a manual interface.


# LOOP START, STOP
# client.loop_start() starts a background thread to handle the network traffic and will return immediately. 
# This is better suited to the situation where you wish to do other tasks in your program. 
# It is complemented by the client.loop_stop() function, which stops the background thread.





###################
# helpers
###################


#https://eclipse.dev/paho/files/paho.mqtt.python/html/helpers.html

#################
# one shot single publish
#################
# This function creates an MQTT client, connects to a broker and publishes a single message. Once the message has been delivered, it disconnects cleanly from the broker.
# return nothing

def one_shot_single_publish(topic, payload, user, password, host="127.0.0.1", qos = 0, retain = False, will = None, protocol= mqtt.MQTTv31):


    # will – a dict containing will parameters for the client: will = {‘topic’: “<topic>”, ‘payload’:”<payload”>, ‘qos’:<qos>, ‘retain’:<retain>}. 
    # Topic is required, all other parameters are optional and will default to None, 0 and False respectively. Defaults to None, which indicates no will should be used.


    auth = {
        "username": user, 
        "password":password
        } 

    publish.single(topic, payload, auth= auth, hostname=host, qos=qos, retain = retain, will = will, protocol = protocol )
    # return nothing
    


#################
# one shot multiple publish
#################

def one_shot_multiple_publish(msgs, user, password, host="127.0.0.1", will = None, protocol= mqtt.MQTTv31):
    # qos, retain not available

    assert type(msgs) is list


    auth = {
        "username": user, 
        "password":password
        } 

    # list of dict or tuple
    msgs = [
        {'topic':"paho/test/topic", 'payload':"multiple 1"},
        ("paho/test/topic", "multiple 2", 0, False)
    ]

    publish.multiple(msgs, auth = auth, hostname=host, will = will, protocol = protocol)



#################
# one shot blocking subscribe
#################
# This module provides some helper functions to allow straightforward subscribing and processing of messages.
# This function creates an MQTT client, connects to a broker and subscribes to a list of topics. Once “msg_count” messages have been received, it disconnects cleanly from the broker and returns the messages.

def one_shot_subscribe(topic, user, password,  host="127.0.0.1", msg_count  = 1, qos = 0, retained = False, will = None, protocol = mqtt.MQTTv31, clean_session = True ):

    # retained (bool) – If set to True, retained messages will be processed the same as non-retained messages. If set to False, retained messages will be ignored.
    # clean_session – If True, the broker will remove all information about this client when it disconnects. If False, the client is a persistent client and subscription information and queued messages will be retained when the client disconnects. Defaults to True. 
    # if protocol is MQTTv50, clean_session is ignored.
    # msg_count (int) – the number of messages to retrieve from the broker. if msg_count == 1 then a single MQTTMessage will be returned. if msg_count > 1 then a list of MQTTMessages will be returned.

    auth = {
        "username": user, 
        "password":password
        }

    # Subscribe to a set of topics and return the messages received. This is a blocking function.
    try:
        print("subscribe to %s and block" %topic)
        ret = subscribe.simple(topic, auth = auth , hostname=host, msg_count = msg_count , qos = qos, retained = retained, will = will, protocol=protocol, clean_session=clean_session)
        
        # this is blocking
        # single or list of message: <paho.mqtt.client.MQTTMessage object at 0xf5666df0>
       
        print("received after blocking on subscribe: return %s" % (str(ret)))


        # https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html#paho.mqtt.client.MQTTMessage
        return(ret)


    except Exception as e:
        print("Exception on shot subscribe: %s" %str(e))
        # eg bad credential
        return(None)


    
#################
# one shot subscribe with callback
#################
# Subscribe to a set of topics and process the messages received using a user provided callback.

def one_shot_subscribe_with_callback(topic, user, password,  host="127.0.0.1", ):

    auth = {
        "username": user, 
        "password":password
        }

    print("subscribe and wait for callback")
    subscribe.callback(on_message, topic, auth = auth, hostname=host, userdata={"message_count": 0})

    # do not return. triggers callback



if __name__ == '__main__':



    #################
    # connect to broker
    #################
    
    client = connect_to_ha_mqtt("meaudre", "meaudre", protocol=mqtt.MQTTv5, persistant=True)

    ##################
    # LOOP
    ##################

    #client.loop_forever()  # BLOCKING
    #print("loop_forever returned. %s" %str(mqttc.user_data_get()))

    # thread
    client.loop_start()

    # new user data
    # there is magic here. userdata is available in on_publish callback, and can be MODIFIED. the modified version is available here
    my_userdata = set()
    my_userdata.add(1)
    client.user_data_set(my_userdata)


    # PAYLOAD
    # payload – The actual message to send. If not given, or set to None a zero length message will be used. 
    # Passing an int or float will result in the payload being converted to a string representing that number. 
    # If you wish to send a true int/float, use struct.pack() to create the payload you require.
    
    # will trigger on_publish callback with updated user data

    # RETAIN
    # The broker stores the last retained message and the corresponding QoS for that topic. 
    # Each client that subscribes to a topic pattern that matches the topic of the retained message receives the retained message immediately after they subscribe. 
    # The broker stores only one retained message per topic.

    # QOS
    # At most once (QoS 0): QoS 0 offers "fire and forget"
    # At least once (QoS 1): QoS 1 ensures that messages are delivered at least once by requiring a PUBACK acknowledgment.
    # Exactly once (QoS 2): QoS 2 guarantees that each message is delivered exactly once by using a four-step handshake (PUBLISH, PUBREC, PUBREL, PUBCOMP).

    ####################
    # publish on status (will) topic
    ###################
    # disconnect() will NOT set this to offline. meant for long live client, or sub client
    msg_info = client.publish(will_topic, online_payload, qos=0, retain= True)

    #######################
    # publish one message
    #######################
    temperature = 19.5
    msg_info = client.publish("meaudre/test", temperature, qos=1, retain= False )
    
    # msg_info returned from Client.publish() and can be used to find out the mid of the message that was published, 
    # and to determine whether the message has been published, and/or wait until it is published.
    # https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html#paho.mqtt.client.MQTTMessageInfo

    print("publish: mid %d" %msg_info.mid)
    print("is published ? %s" %msg_info.is_published())

    #  give status for this message. This value could change until the message is_published
    print("error code %s" %str(msg_info.rc)) 
    # error code MQTTErrorCode.MQTT_ERR_SUCCESS


    # wait for the message to be published

    try:
        # Block until the message associated with this object is published, or until the timeout occurs.
        msg_info.wait_for_publish(3.3) # timeout in sec
        print("message is published")
    except Exception as e:
        print("Exception waiting for message to be published %s" %str(e))


    # user data was modified in on_publish callback
    print("user data as updated by on_publish() callback:", my_userdata)

    
    ###############
    # ON SHOT PUBLISH
    ##############
    one_shot_single_publish("meaudre/test", "oneshot single publish", "meaudre" , "meaudre")

    # return nothing


    ###############
    # ON SHOT PUBLISH multiple
    ##############

    # list of dict or tuple
    msgs = [
        {'topic':"paho/test/topic", 'payload':"multiple 1"},
        ("paho/test/topic", "multiple 2", 0, False)
    ]


    ##################
    # subscribe
    ##################

    # return tuple[MQTTErrorCode, int | None]

    # subscribe(“my/topic”, 2)
    # subscribe((“my/topic”, 1))
    # subscribe([(“my/topic”, 0), (“another/topic”, 2)])

    ret = client.subscribe([("meaudre/test/sub",0)] )
    #print(ret) # (<MQTTErrorCode.MQTT_ERR_SUCCESS: 0>, 3)
    if ret is not None:
        err_code = ret[0].value
        err_name =  ret[0].name

        if err_code != 0 or err_name != "MQTT_ERR_SUCCESS":
            print("subscribe FAILED: code %d, name %s" %(err_code, err_name))
        else:
            print("subscribe OK")


    ################
    # message handled in callback
    ################
    got_msg = False

    print("waiting for a message 1 (callback)")
    while not got_msg:
        sleep(1)



    ############################################
    # using helpers
    ############################################



    ####################
    # oneshot subscribe (blocking)
    ####################

    print("waiting for a message 2")
    ret = one_shot_subscribe("meaudre/test/sub", "meaudre", "meaudre")

    # msg or list 

    if ret is None:
        print("error one shot subscribe")

    else:

        if isinstance(ret, list):
            pass
        else:
            ret = [ret] # <paho.mqtt.client.MQTTMessage object at 0xf5666df0>


        for x in ret:

            _topic = x.topic
            payload = x.payload = x # <paho.mqtt.client.MQTTMessage object at 0xf5666df0>
            qos = x.qos
            retain = x.retain
            timestamp = x.timestamp

            if isinstance(payload, (bytes, bytearray)):
                mes = payload.decode() # bytes to str

                # assume json
                mes = json.loads(mes) # str to dict

                print("byte msg:", mes)

            else:
                print("str msg:", payload)

            print("received topic:", _topic)
            print("qos", qos)
            print("retain" , retain)


    ####################
    # oneshot subscribe (callback)
    ####################
    got_msg = False
    one_shot_subscribe_with_callback("meaudre/test/sub", "meaudre", "meaudre")

    # WARNING: this does not return and stay waiting for callback. 
    # This function creates an MQTT client, connects to a broker and subscribes to a list of topics. Incoming messages are processed by the user provided callback. 
    # This is a blocking function and will never return.

    # also at this point there are two clients trigerring the same on_message call back
    
    # should not get there


    # DOES NOT SEND WILL. could use another topic
    client.disconnect()





