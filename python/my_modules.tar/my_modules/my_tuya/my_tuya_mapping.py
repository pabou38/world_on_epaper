#!/usr/bin/python

"""
Polling local devices...
    [maxio plug               ] 192.168.1.27       - [On]  - DPS: {'1': True, '27': True, '28': 'colour', '29': 255, '31': '00ff0100786464', '32': 'bd76000168ffff', '33': 'ffff500100ff00', '34': 'ffff8003ff000000ff000000ff000000000000000000', '35': 'ffff5001ff0000', '36': 'ffff0505ff000000ff00ffff00ff00ff0000ff000000'}
    [smart meter with CT-2    ] 192.168.1.18       - [Off] - DPS: {'1': False, '18': 0, '19': 0, '20': 2391, '26': 0, '102': 84, '103': 125, '104': 2398, '107': 2000, '108': 0}
"""


######################################
# mapping information from index to what the fuck it is
######################################


##############
# relay
##############


# 1 is status of relay 
# from devices.json
plug_mapping = {
            "1": {
                "code": "switch_1",
                "type": "Boolean",
                "values": {}
            },
            "27": {
                "code": "switch_led",
                "type": "Boolean",
                "values": {}
            },
            "28": {
                "code": "work_mode",
                "type": "Enum",
                "values": {
                    "range": [
                        "white",
                        "colour",
                        "scene",
                        "music",
                        "scene_1",
                        "scene_2",
                        "scene_3",
                        "scene_4"
                    ]
                }
            },
            "29": {
                "code": "bright_value",
                "type": "Integer",
                "values": {
                    "min": 25,
                    "scale": 0,
                    "unit": "",
                    "max": 255,
                    "step": 1
                }
            },
            "31": {
                "code": "colour_data",
                "type": "Json",
                "raw_values": "{}",
                "values": {}
            }

}

# colour_data 6c7a6400631230
# colour_data f2112101635d5f
# slider brigthess and saturation seems to influence colour_data, not bright value
# bright_value 255




####################
# EM
###################

# {'1': False, '2': False, 

# '17': 4, '18': 40, '19': 85, '20': 2403, 

# '26': 0, 

# '101': 5, '102': 68, '103': 102, 

# '104': 2402, 

# '107': 2010, '108': 1050}

# see also https://github.com/jasonacox/tinytuya
# cloud , API management , device control, query property     enter device id, code empty

# 17 add_ele kwh, ie energy
# 18 cur_current A   max 80 000 scale 3 , ie / 1000, ie value in ma max 80A
# 19 cur_power W     max 200000  scale 1 , ie   /10  to get W
# 20 cur_voltage V   max 5000 scale 1, ie /10 to get Volt. max 500 V

# 26 fault bitmap


# 101 add_ele2
# 102 current 2 , 103 power 2
# 104 volt 2

# 107,108 = overpower per ct configured in app



em_mapping = {  
        "1": {
            "code": "switch_1",
            "type": "Boolean",
            "values": {}
        },
        "2": {
            "code": "switch_2",
            "type": "Boolean",
            "values": {}
        },
        "17": {
            "code": "add_ele",
            "type": "Integer",
            "values": {
                "unit": "kwh",
                "min": 0,
                "max": 50000,
                "scale": 3,
                "step": 100
            }
        },
        "18": {
            "code": "cur_current",
            "type": "Integer",
            "values": {
                "unit": "A",
                "min": 0,
                "max": 80000,
                "scale": 3,
                "step": 1
            }
        },
        "19": {
            "code": "cur_power",
            "type": "Integer",
            "values": {
                "unit": "W",
                "min": 0,
                "max": 200000,
                "scale": 1,
                "step": 1
            }
        },
        "20": {
            "code": "cur_voltage",
            "type": "Integer",
            "values": {
                "unit": "V",
                "min": 0,
                "max": 5000,
                "scale": 1,
                "step": 1
            }
        }
}