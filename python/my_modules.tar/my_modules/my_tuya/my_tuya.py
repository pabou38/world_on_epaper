#!/usr/bin/python


# https://github.com/jasonacox/tinytuya

# https://github.com/jasonacox/tuyapower

# iot.tuya.com

# https://hittheroad.dev/howto-integrate-tuya-wifi-energy-meter-into-home-assistant-5739806378c5


version = 1.1 # 17 dec 2024
version = 1.2 # 17 dec 2024   success with CT, plug
version = 1.3 # 30 jan 2025. clean, 2CT, find dps
version = 1.31 # 31 jan 2025. update dps. fixes mess with value not updated until smartlife app not opened
version = 1.32 # 20 feb 2025. move to meaudre
version = 1.33 # 5 june 2025 


import tinytuya
import my_tuya_mapping

import sys
from time import sleep
import subprocess, json





####################
#SNAPSHOT
####################

"""
for all registered devices, online or not
returns current value of dps and KEY

load CURRENT snapshot.json and POLL

###### this seems to do polling (vs scan)
###### ie response is immediate, unlike everything that has to do with scan
# display the status of all devices on record and create a snapshot.json

# avoid re nitemare and get json (as text)
==== > python -m tinytuya json -snapshot-file snapshot_em.json

#  python -m tinytuya snapshot -snapshot-file snapshot_em.json -y  # stdout

TinyTuya (Tuya device scanner) [1.15.1]
Loaded .\snapshot_em.json - 1 devices:
Name                      ID                       IP              Key               Version
smart meter with CT-2     bf38fe670c2fc3f62fsadz   192.168.1.18    fr9iN>HqFe_.'KUP  3.4
Polling 1 local devices from last snapshot...
    [smart meter with CT-2    ] 192.168.1.18       - [Off] - DPS: {'1': False, '18': 0, '19': 0, '20': 2394, '26': 0, '101': 6, '102': 82, '103': 127, '104': 2403, '107': 2010, '108': 1050}
Done.


# python -m tinytuya snapshot -snapshot-file snapshot.json -y

TinyTuya (Tuya device scanner) [1.15.1]
Loaded snapshot.json - 2 devices:
Name                      ID                       IP              Key               Version
maxio plug                11037543840d8e9e4930     192.168.1.27    staT(<{|rrK{xJ>9  3.1
smart meter with CT-2     bf38fe670c2fc3f62fsadz   192.168.1.18    fr9iN>HqFe_.'KUP  3.4
Polling 2 local devices from last snapshot...
    [maxio plug               ] 192.168.1.27       - [On]  - DPS: {'1': True, '27': True, '28': 'colour', '29': 255, '31': '00ff0100786464', '32': 'bd76000168ffff', '33': 'ffff500100ff00', '34': 'ffff8003ff000000ff000000ff000000000000000000', '35': 'ffff5001ff0000', '36': 'ffff0505ff000000ff00ffff00ff00ff0000ff000000'}
    [smart meter with CT-2    ] 192.168.1.18       - [Off] - DPS: {'1': False, '18': 0, '19': 0, '20': 2405, '26': 0, '101': 6, '102': 74, '103': 114, '104': 2401, '107': 2010, '108': 1050}

Done.
"""

###############
# SCAN
###############

"""
find tuya devices ONLINE on local network
returns IP,version, device id (same as iot.cloud.com)
does NOT return local key

====> python -m tinytuya scan, or PS> tinytuya scan

Unknown v3.1 Device   Product ID = dYn2mDKmgV2Zz2YX  [Valid Broadcast]:
    Address = 192.168.1.27   Device ID = 11037543840d8e9e4930 (len:20)  Local Key =   Version = 3.1  Type = default, MAC = 84:0d:8e:9e:49:30
    Status: {'1': False, '27': True, '28': 'colour', '29': 255, '31': '25ff00006fffff', '32': '00ff0000000000', '33': 'ffff500100ff00', '34': 'ffff8003ff000000ff000000ff000000000000000000', '35': 'ffff5001ff0000', '36': 'ffff0505ff000000ff00ffff00ff00ff0000ff000000'}

"""


###########################################
##################
# get "local" keys needed to access using API
##################
#############################################

# method 1: output of snapshot
# part of tinytuya -wizard
# or tinytuya - snapshot

# smart meter with CT-2     bf38fe670c2fc3f62fsadz   192.168.1.18    fr9iN>HqFe_.'KUP  3.4

# also found in snapshot.json
#"name": "smart meter with CT-2"
#"key": "fr9iN>HqFe_.'KUP",

###### WTF. does not always seem to work


# method 2: API explorer

# cloud -> API explorer -> device management -> query device details (enter device id)
# look at json response "local_key": "fr9iN>HqFe_.'KUP",


# HOME ASSISTANT
# in localtuya HA integration. retrieved automatically when cloud API configured
# staT(<{|rrK{xJ>9
# fr9iN>HqFe_.'KUP

# NOTE: tinytuya scan seems to report EVERYTHING after a while, ie key, dps value ...
#  Address = 192.168.1.18   Device ID = bf38fe670c2fc3f62fsadz (len:22)  Local Key = fr9iN>HqFe_.'KUP



plug_key = "fGihv56=DBnq*Ela"
plug2_key = "b9L6>3>Tf8n<H~L5"
em_key   = "KX#6dsu2TCbq}Rla"


################################
# only local key and device id used by tinyTuya API call
################################

# Alternative connection - for some devices with 22 character IDs they require a special handling
#    d=tinytuya.OutletDevice(DEVICEID, DEVICEIP, DEVICEKEY, 'device22')
#    d.set_dpsUsed({"1": None}) 
#    d.set_version(3.3)

em_keys = {
    "apiKey": "qunuupjmqpjmkwvc4dje",
    "apiSecret": "109ca49ebbf4488da3820cb2af803ece",
    "apiRegion": "eu",
    "apiDeviceID": "bf38fe670c2fc3f62fsadz",
    "local_key" : em_key 
}

# bf 38 fe 67 0c 2f c3 f6 2f sa dz
# 11 03 75 43 84 0d 8e 9e 49 30

plug_keys = {
    "apiKey": "qunuupjmqpjmkwvc4dje",
    "apiSecret": "109ca49ebbf4488da3820cb2af803ece",
    "apiRegion": "eu",
    "apiDeviceID": "11037543840d8e9e4930",
    "local_key" : plug_key
}


# can get IP, version from python -m tinytuya scan

##################
# IP address
##################
tuya_plug = ("192.168.1.27", 3.1, plug_keys, my_tuya_mapping.plug_mapping)

# IP fixed in router based on MAC
tuya_em = ("192.168.1.174", 3.4, em_keys, my_tuya_mapping.em_mapping)


################################
# get power using tinytuya snapshot
# DEPRECATED, as API call works
################################
def get_ct1203_snapshot():

    # python -m tinytuya json -snapshot-file snapshot_em.json


    # SUBPROCESS call
    # capture_output: When set to True, will capture the standard output and standard error.
    # text: When set to True, will return the stdout and stderr as string, otherwise as bytes.
    # check: a boolean value that indicates whether to check the return code of the subprocess, if check is true and the return code is non-zero, then subprocess CalledProcessError is raised.
    # timeout: A value in seconds that specifies how long to wait for the subprocess to complete before timing out.
    # shell: A boolean value that indicates whether to run the command in a shell. This means that the command is passed as a string, and shell-specific features, such as wildcard expansion and variable substitution, can be used.

    try:
        result = subprocess.run(["python", "-m", "tinytuya", "json", "-snapshot-file", "snapshot_em.json"], capture_output=True, text=True, check=True, timeout=10)

        #print(result.args)
        ret_code = result.returncode
        if ret_code != 0:
            print("ret code %d" %ret_code)
            print(result.stderr)
            return(None, None, None)
        
        else:

            j = result.stdout

            ###################
            # WTF, this is not a json, but a str with a lot of formatting
            # dps": {\r\n                "1": false,\r\n                "18": 0,\r\n
            ###################
            #print(j)

            obj = json.loads(j)

            volt = obj["devices"] [0] ["dps"] ["20"]/10
            power = obj["devices"] [0] ["dps"] ["19"]/10
            amps = obj["devices"] [0] ["dps"] ["18"]/1000

            
            return(power, volt, amps)

    except Exception as e:
        print("error snapshot", str(e))
        return(None, None, None)


# device permission 
# https://www.tuyaos.com/viewtopic.php?t=3004
# Subsequently, by sending commands to the device using the OpenAPIs（e.g. POST:/v1.0/devices/{device_id}/commands）, its permissions will be upgraded to 'Read/Write', making it controllable.
#Also, remember that this will consume from the controllable device pool. When the quota is depleted (for example, in the case of the IoT core trial edition, with a limit of 5 controllable devices), new devices will no longer be controllable."



###########################
# scan to stdout
# LONGGGGGGG 18 sec, as wait for broadcast
# get dps values  
# result to stdout
###########################

def scan_to_stdout():  
    # welcome re
    print("\nINTERACTIVE Scanning local network for Tuya devices...")
    # OK get EM dps values
    # The function tinytuya.scan() will listen to your local network (UDP 6666 and 6667) and identify Tuya devices broadcasting their Address, Device ID, Product ID and Version and will print that and their stats to stdout. This can help you get a list of compatible devices on your network. 
    
    tinytuya.scan()

    """
    INTERACTIVE Scanning local network for Tuya devices...

        TinyTuya (Tuya device scanner) [1.15.1]

        [Loaded devices.json - 2 devices]

        Scanning on UDP ports 6666 and 6667 and 7000 for devices for 18 seconds...

        New Broadcast from App at 192.168.1.139 - {'from': 'app', 'ip': '192.168.1.139'}
        maxio plug   Product ID = dYn2mDKmgV2Zz2YX  [Valid Broadcast]:
            Address = 192.168.1.27   Device ID = 11037543840d8e9e4930 (len:20)  Local Key = staT(<{|rrK{xJ>9  Version = 3.1  Type = default, MAC = 84:0d:8e:9e:49:30
            Status: {'1': True, '27': True, '28': 'colour', '29': 255, '31': '00ff0100786464', '32': 'bd76000168ffff', '33': 'ffff500100ff00', '34': 'ffff8003ff000000ff000000ff000000000000000000', '35': 'ffff5001ff0000', '36': 'ffff0505ff000000ff00ffff00ff00ff0000ff000000'}
        smart meter with CT-2   Product ID = key8p7ad97798n97  [Valid Broadcast]:
            Address = 192.168.1.18   Device ID = bf38fe670c2fc3f62fsadz (len:22)  Local Key = fr9iN>HqFe_.'KUP  Version = 3.4  Type = default, MAC = 38:a5:c9:89:42:1f
            Status: {'1': False, '18': 0, '19': 0, '20': 2394, '26': 0, '102': 0, '103': 0, '104': 0, '107': 2010, '108': 1050}       
        Scan completed in 18.0745 seconds

        Scan Complete!  Found 2 devices.
        Broadcasted: 2
        Versions: 3.1: 1, 3.4: 1

        >> Saving device snapshot data to snapshot.json
    """


####################
# scan to dict
# get dps values
####################
def scan_to_dict(): # returns dict

    # The tinytuya.deviceScan() function returns all found devices and their stats (via dictionary result).
    # OK get dps

    # Scan network for devices and provide polling data
    print("\nDICTIONARY Scanning local network for Tuya devices...")

    devices = tinytuya.deviceScan(False, 30)

    if not devices:   # empty = False
        print("no tuya devices found")
        return None
    
    #print(devices)
    print("found %d devices" %len(devices))

    for d in devices:
        print(d, devices[d]["name"], devices[d] ["version"] , devices[d] ["dps"] ["dps"])
        # {'ip': '192.168.1.18', 'gwId': 'bf38fe670c2fc3f62fsadz', 'active': 2, 'encrypt': True, 'productKey': 'key8p7ad97798n97', 'version': '3.4', 'token': True, 'wf_cfg': True, 'name': 'smart meter with CT-2', 'key': "fr9iN>HqFe_.'KUP", 'mac': '38:a5:c9:89:42:1f', 'id': 'bf38fe670c2fc3f62fsadz', 'ability': 0, 'dev_type': 'default', 'err': '', 'type': 'default', 'dps': {'dps': {...}}, 'origin': 'broadcast'}

   
    """
    DICTIONARY Scanning local network for Tuya devices...
    found 2 devices
    192.168.1.27 maxio plug 3.1 {'1': True, '27': True, '28': 'colour', '29': 255, '31': '00ff0100786464', '32': 'bd76000168ffff', '33': 'ffff500100ff00', '34': 'ffff8003ff000000ff000000ff000000000000000000', '35': 'ffff5001ff0000', '36': 'ffff0505ff000000ff00ffff00ff00ff0000ff000000'}
    192.168.1.18 smart meter with CT-2 3.4 {'1': False, '18': 0, '19': 0, '20': 2394, '26': 0, '102': 0, '103': 0, '104': 0, '107': 2010, '108': 1050}
    """

    return (devices)


###############
# use scan to dict to extract power , as dps value available
# DEPRECATED, as API call works
##############
def scan_power(ip):

    # get power info using scan
    devices = tinytuya.deviceScan(False, 30)

    if not devices:   # empty = False
        print("no tuya devices found")
        return (None,None,None)
    
    #print(devices)
    #print("found %d devices" %len(devices))

    try:
        power_dict = devices[ip] ["dps"] ["dps"]
        power = power_dict["19"]
        volt = power_dict["20"]/10
        amps = power_dict["18"]/1000

        print("%0.1fV, %0.1fW, %0.1fA" %(volt, power, amps))
        return(power, volt, amps)
    
    except:
        return(None,None,None)



###########
# turn relay on/off 
###########
def switch(d):
    # Turn On
    print("turn on")
    print(d.turn_on())
    sleep(2)
    # Turn Off
    print("turn off")
    print(d.turn_off())
    
    
#####################
# toggle switch 
#####################
def toggle(dps):
    # Toggle switch state
    switch_state = dps['1']
    print("toggling from: %s" %switch_state)
    # default 1
    data = d.set_status(not switch_state)  # This requires a valid key
    if "Error" in data.keys():
        print("error tuya", data)
        del(d)
        sys.exit()
    if data:
        print('set_status() result %r' % data)
    # set_status() result {'Error': 'Network Error: Unable to Connect', 'Err': '901', 'Payload': None}


#####################
# pool
#####################

def pool(d):
    # You can set up a persistent connection to a device and then monitor the state changes with a continual loop. This is helpful for troubleshooting and discovering DPS values.
    print("pooling ..")
    print(" > Begin Monitor Loop <")
    d.status(nowait=True)
    while(True):
        # See if any data is available
        data = d.receive()
        print('Received Payload: %r' % data)

        # Send keep-alive heartbeat
        if not data:
            print(" > Send Heartbeat Ping < ")
            d.heartbeat()

        # NOTE If you are not seeing updates, you can force them - uncomment:
        print(" > Send Request for Status < ")
        d.status(nowait=True)

        # NOTE Some smart plugs require an UPDATEDPS command to update power data
        print(" > Send DPS Update Request < ")
        payload = d.generate_payload(tinytuya.UPDATEDPS)
        d.send(payload)


####################
# print status, ie actual values
# use mapping info returned by devices.json
# see https://github.com/jasonacox/tinytuya for some standard mapping 
####################

def print_status_with_mapping(d):
    # Get Status
    print("\nget tuya status")

    data = d.status()

    print('status(): %r' % data)
    # {'Error': 'Network Error: Unable to Connect', 'Err': '901', 'Payload': None}

    # status(): {'dps': {'1': False, '2': False, '17': 4, '18': 40, '19': 85, '20': 2403, '26': 0, '101': 5, '102': 68, '103': 102, '104': 2402, '107': 2010, '108': 1050}}
   
    if "Error" in data.keys():
        print("error tuya. make sure smartlife app is closed and not running in background")
        del(d)
        sys.exit()

    # for 1 is status of relay

    dps = data["dps"] # get dict

    for x in dps: # for all keys, ie index

        try:
            print("code: %s, value: %r, values info: %r" %(mapping[x]["code"], dps[x],mapping[x]["values"] )) # value is empty dict for bool, contains scale for int
        
        except Exception as e:

            # key not in devices.json
            print("key %r not in device.json. value %r" %(x, dps[x]))



############################
# detect available dps
# scan for device id or IP , does not return dps
# read mapping from json file
# DOES NOT PROVIDE VALUE
# NOT USEFULL
############################

def some_detection(d):
    print("detect available dps")
    ret = d.detect_available_dps()
    print(ret)
    # {'1': None, '27': None, '28': None, '29': None, '31': None, '32': None, '33': None, '34': None, '35': None, '36': None}


    # does not include dps !!!
    # Scans network for Tuya devices with either ID = dev_id or IP = address
    ret = tinytuya.find_device(dev_id, address)         
    print(ret)
    #{'ip': '192.168.1.18', 'version': '3.4', 'id': 'bf38fe670c2fc3f62fsadz', 'product_id': 'key8p7ad97798n97', 'data': {'ip': '192.168.1.18', 'gwId': 'bf38fe670c2fc3f62fsadz', 'active': 2, 'encrypt': True, 'productKey': 'key8p7ad97798n97', 'version': '3.4', 'token': True, 'wf_cfg': True, 'name': 'smart meter with CT-2', 'key': "fr9iN>HqFe_.'KUP", 'mac': '38:a5:c9:89:42:1f', 'id': 'bf38fe670c2fc3f62fsadz', 'ability': 0, 'dev_type': 'default', 'origin': 'broadcast'}}

    # Searches DEVICEFILE (usually devices.json) for device with ID
    # json with mapping
    ret= tinytuya.device_info(dev_id)
    print(ret)


############################
# tuyapower
# desparate try before ligth
# DEPRECATED
############################
def do_tuyapower(dev_id,address,local_key,version):

    # pip install pycryptodome

    import tuyapower

    print("\ntuyapower: deviceScan")
    tuyapower.deviceScan(True)

    """
    FOUND Device [Valid payload]: 192.168.1.27
    ID = 11037543840d8e9e4930, product = dYn2mDKmgV2Zz2YX, Version = 3.1
    Stats: on=True [Power data unavailable]
    FOUND Device [Valid payload]: 192.168.1.18
    ID = bf38fe670c2fc3f62fsadz, product = key8p7ad97798n97, Version = 3.4
    Device Key required to poll for stats
    """

    print("\ntuyapower: devicePrint", address)
    tuyapower.devicePrint(dev_id,address,local_key,version)

    print("\ntuyapower: deviceInfo", address)
    (on, w, mA, V, err) = tuyapower.deviceInfo(dev_id,address,local_key,version)
    print(address, on, w, mA, V, err)
    # PLUG: True 0 0 0 Power data unavailable


######################
# create tuya device
#   IP, device id, version, local key
######################

def create_tuya(dev_id, address, local_key, version, do_22 = False):

    # Connect to Device
    # need local key to access locally
    # cloud access is needed to get local key. not technically needed after

    # Tuya devices only allow one TCP connection at a time. Make sure you close the TuyaSmart or SmartLife app before using TinyTuya to connect.

    # Version - Tuya protocol version used (3.1, 3.2, 3.3, 3.4 or 3.5)
    # get from scan

    #d = tinytuya.Device(dev_id=dev_id, address= address, local_key=local_key, version = 3.1 )

    # Some devices with 22 character IDs will require additional setting to poll correctly. TinyTuya will attempt to detect and accomodate for this, but it can be specified directly:
    #d = tinytuya.Device(dev_id, address, local_key, 'device22')
    #d.set_dpsUsed({"19": None})  # This needs to be a datapoint available on the device
   
    if do_22:

        print("using device22")

        d = tinytuya.Device(dev_id, address, local_key, "device22")
        d.set_dpsUsed({"19": None})

    else:

        print("NOT using device22")

        d = tinytuya.Device(dev_id, address, local_key)

    print("set version to %s" %version)
    d.set_version(version)

    #d.set_socketPersistent(True)  # Optional: Keep socket open for multiple commands

    return(d)



##############################
# get reading from EM
# use status

# energy flows from K to L
# grid K -> L load on phase: 600W
# grid K -> L load on neutral: 600W

#### need update dps before status.
# otherwize fucked behavior. value not updated until smartlife applicatiuon is opened and look at EM
# then if app is killed, value not updated when  load is turnerd on

# returns list of tuple
# returns empty list in error

##############################
def get_ct1203(d) -> list:

    ret = []

    # Option for Power Monitoring Smart Plugs - Some require UPDATEDPS to update power data points
    # https://github.com/jasonacox/tinytuya/blob/d7e621f1ccfb993eb1edb8e9ff044b748dc7a55b/examples/getstatus.py
    payload = d.generate_payload(tinytuya.UPDATEDPS,['17', '18','19','20', '101', '102', '103', '104'])
    d.send(payload)


    try:
        data = d.status()
        #print(data)

    except Exception as e:
        print("exception tuya status: %s" %str(e))
        return([])


    # WARNING: energy may not be there when just plugged ????
    # two ct connected
    # {'dps': {'1': False, '2': False, '17': 4, '18': 40, '19': 85, '20': 2403, '26': 0, '101': 5, '102': 68, '103': 102, '104': 2402, '107': 2010, '108': 1050}}
    
    # single ct no kwh ????
    # {'dps': {'1': False, '18': 0, '19': 0, '20': 2403, '26': 0, '102': 0, '103': 0, '104': 2401, '107': 2010, '108': 1050}}
    
    
    # use mapping to figure out scale

    # energy not there when just plugged ?
    try:
        energy = data["dps"]["17"]/1000
    except:
        energy = None

    try:

        amps  = data["dps"]["18"]/1000
        watt = data["dps"]["19"]/10
        volt  = data["dps"]["20"]/10

        ret.append((energy, amps, watt, volt))
    except:
        pass

    # if 2nd CT exist
    try:
        energy2 = data["dps"]["101"]/1000
    except:
        energy2 = None

    try:
        amps2  = data["dps"]["102"]/1000
        watt2 = data["dps"]["103"]/10
        volt2  = data["dps"]["104"]/10

        ret.append((energy2, amps2, watt2, volt2))
    except:
        pass


    return(ret)






if __name__ == "__main__":

    ################
    # select tuya device
    ###############
    tuya = tuya_plug

    tuya = tuya_em

    address = tuya[0]
    version = tuya[1]
    dev_id = tuya[2] ["apiDeviceID"]
    local_key = tuya[2] ["local_key"]
    
    
    mapping = tuya[3]


    ################
    # tuyapower
    ################
    #do_tuyapower(dev_id,address,local_key,version)


    ###################
    # SCAN
    ###################

    # interactive
    #scan() 

    # return dict
    #f = devices_scan()

    # scan power
    # using tinytuya.deviceScan(False, 30)
    #(power, volt, amps) = scan_power(tuya_em[0]); print("from scan: %0.1fW %0.1fV %0.1fA" %(power, volt, amps))


    #####################
    # create device
    # need devid, ip, local key, version
    #####################

    # Tuya devices only allow one TCP connection at a time. Make sure you close the TuyaSmart or SmartLife app before using TinyTuya to connect.

    # https://github.com/rospogrigio/localtuya/issues/1253
        
    d = create_tuya(dev_id, address, local_key, version, do_22=False)

    #    d=tinytuya.OutletDevice(DEVICEID, DEVICEIP, DEVICEKEY, 'device22')
    #    d.set_dpsUsed({"1": None}) 
    #    d.set_version(3.3)

    dps = d.detect_available_dps()
    print("available dps: ", dps)

    # list DPS, no value
    # EM: available dps:  {'1': None, '17': None, '18': None, '19': None, '20': None, '26': None, '101': None, '102': None, '103': None, '104': None, '107': None, '108': None}



    ####################
    # processing on d
    ####################

    # contains actual values
    print_status_with_mapping(d)

    #{'dps': {'1': False, '17': 4, '18': 37, '19': 79, '20': 2392, '26': 0, '101': 5, '102': 69, '103': 100, '104': 2389, '107': 2010, '108': 1050}}


    """
    switch_1 True
    switch_led True
    work_mode colour
    bright_value 255
    colour_data 00ff0100786464
    error key '32' not in device.json
    error key '33' not in device.json
    error key '34' not in device.json
    error key '35' not in device.json
    error key '36' not in device.json


    status() result {'dps': {'1': False, '18': 0, '19': 0, '20': 2403, '26': 0, '102': 0, '103': 0, '104': 2399, '107': 2010, '108': 1050}}
    switch_1 False
    cur_current 0
    cur_power 0
    cur_voltage 2403
    error key '26' not in device.json
    error key '102' not in device.json
    error key '103' not in device.json
    error key '104' not in device.json
    error key '107' not in device.json
    error key '108' not in device.json


    """

#####################
# play with plug
#####################

if tuya is tuya_plug:

    print("turn plug on")
    ret= d.turn_on()
    print(ret) # {'devId': '11037543840d8e9e4930', 'dps': {'1': True}, 't': 1734434533, 's': 3}
    sleep(2)
    ret = d.turn_off() 
    print(ret) # {'devId': '11037543840d8e9e4930', 'dps': {'1': False}, 't': 1734434552, 's': 4}

    # set_status(on, switch=1, nowait)              # Set status of switch to 'on' or 'off' (bool)
    data = d.set_status(True)
    print(data) #{'devId': '11037543840d8e9e4930', 'dps': {'1': True}, 't': 1734434566, 's': 5}

#####################
# play with EM
#####################

if tuya is tuya_em:

    print("reading EM values")

    for _ in range(100):

        ret  = get_ct1203(d)
        # list of tuple. empty list for error

        #CT1: 0.001kwh, 1795W (real/active), 225.7V, 7.744A, pf:1.0 
        #CT2: 0.001kwh, 1793W (real/active), 225.6V, 7.737A, pf:1.0

        if ret == []:
            print("error reading EM value")

        else:
            (energy, amps, watt, volt) = ret[0]

            if volt*amps !=0:
                pf = watt/(volt*amps)
            else:
                pf = -1
            print("CT1: %rkwh, %0.0fW (real/active), %0.1fV, %0.3fA, pf:%0.1f " %(energy, watt, volt, amps, pf))


            # if CT2 exists
            if len(ret) == 2:
                (energy2, amps2, watt2, volt2) = ret[1]
                if volt2*amps2 !=0:
                    pf2 = watt2/(volt2*amps2)
                else:
                    pf2 = -1
                print("CT2: %rkwh, %0.0fW (real/active), %0.1fV, %0.3fA, pf:%0.1f" %(energy2, watt2, volt2, amps2, pf2))

        
        print("\n")
        sleep(4)



        """
        aspi

        CT1: 0.028kwh, 649W (real/active), 237.8V, 3.504A, pf:0.8 
        CT2: 0.027kwh, 646W (real/active), 237.9V, 3.504A, pf:0.8

        WTF 237 * 3,5 = 829 so is VA , aka apparent power
        power from EM is real or actice

        644/829   real or active power ./ apparent power = PF

        device rated 800W

        
        boiler

        CT1: 0.028kwh, 1024W (real/active), 236.5V, 4.220A, pf:1.0 
        CT2: 0.027kwh, 1023W (real/active), 236.6V, 4.214A, pf:1.0


        radiateur thomson

        ventilo only
        CT1: 0.001kwh, 17W (real/active), 232.1V, 0.112A, pf:0.7 
        CT2: 0.001kwh, 22W (real/active), 231.8V, 0.113A, pf:0.8

        position 1
        CT1: 0.001kwh, 952W (real/active), 230.7V, 4.015A, pf:1.0 
        CT2: 0.001kwh, 948W (real/active), 229.9V, 4.015A, pf:1.0

        position 2
        CT1: 0.001kwh, 1797W (real/active), 225.8V, 7.747A, pf:1.0 
        CT2: 0.001kwh, 1791W (real/active), 225.4V, 7.739A, pf:1.0
    
        """



